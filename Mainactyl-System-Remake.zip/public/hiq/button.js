function createsrv() {
    window.location.href="/dashboard/createservers.php";
}