function fetchserverlist () {
    document.getElementById("servercontent").style.display = "none";
}