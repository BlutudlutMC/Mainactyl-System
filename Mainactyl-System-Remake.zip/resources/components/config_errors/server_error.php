<?php
require("index.php");
require("dashboard/index.php");
?>
<!DOCTYPE HTML>
<html>
<head>
<title>500</title>
</head>
<body>
<p>Server Error | 500</p>
<p><?php echo $server_error; ?></p>
</body>